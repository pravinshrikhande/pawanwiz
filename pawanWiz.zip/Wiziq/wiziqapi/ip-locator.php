<?php
/**
 * Get time zone
 * @param string $country
 * @param string $region
 * @return string If the timezone is not found, returns null`
 */
class Wiziq_Iplocator{
function ip_visitor_country()
{
    require_once("ip_timezone.php");
	$ip_timezone = new Ip_Timezone();
    $client  = $ip_timezone->getRealIpAddr(); //@$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $country  = "Unknown";

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=".$ip);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $ip_data_in = curl_exec($ch); // string
    curl_close($ch);

    $ip_data = json_decode($ip_data_in,true);
    $ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/
    if($ip_data && $ip_data['geoplugin_countryCode'] != null) {
        $country = $ip_data['geoplugin_countryCode'];
    }

    return $ip_timezone->get_time_zone($country , @$ip_data['geoplugin_regionCode']);
}
function getDiffrenceTimezone($studentTimezone , $courseTimezone)
{
    date_default_timezone_set($studentTimezone);
    $lex = date('Y-m-d H:i:s');
    date_default_timezone_set($courseTimezone);
    $cebu = date("Y-m-d H:i:s");
    $getdifference = (strtotime($lex) - strtotime($cebu))/60;

    $zero    = new DateTime('@0');
    $offset  = new DateTime('@' . $getdifference * 60);
    $diff    = $zero->diff($offset);
    $getdifference = $diff->format('%R%a Days, %R%h Hours, %R%i Minutes');
    return  $getdifference;
}
}
?>
